// Importa componentes do React Native.
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

// Importa o Link para navegação.
import { Link } from 'expo-router';

// Define a tela de destinos.
export default function Destinos() {
  return (
    <View style={styles.container}>
      {/* Título da tela. */}
      <Text style={styles.titulo}>Destinos</Text>

      {/* Card de um destino. */}
      <View style={styles.card}>
        <Image
          source={require('../assets/praia.png')}
          style={styles.imagem}
        />

        {/* Nome do destino. */}
        <Text style={styles.nome}>Rio de Janeiro</Text>

        {/* Descrição. */}
        <Text style={styles.info}>
          Praias, natureza e pontos turísticos.
        </Text>

        {/* Link para detalhes. */}
        <Link href="/detalhes" asChild>
          <TouchableOpacity style={styles.botao}>
            <Text style={styles.textoBotao}>Ver detalhes</Text>
          </TouchableOpacity>
        </Link>
      </View>

      {/* Link para voltar ao início. */}
      <Link href="/" asChild>
        <TouchableOpacity style={styles.voltar}>
          <Text style={styles.textoVoltar}>Voltar para início</Text>
        </TouchableOpacity>
      </Link>
    </View>
  );
}

// Define os estilos.
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  card: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  imagem: {
    width: '100%',
    height: 180,
    borderRadius: 8,
    marginBottom: 12,
  },
  nome: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  info: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 15,
  },
  botao: {
    backgroundColor: '#1976D2',
    padding: 12,
    borderRadius: 8,
    width: 180,
  },
  textoBotao: {
    color: 'white',
    textAlign: 'center',
  },
  voltar: {
    marginTop: 20,
  },
  textoVoltar: {
    color: '#1976D2',
    fontSize: 16,
  },
});