// Importa componentes do React Native.
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

// Importa o Link para navegação.
import { Link } from 'expo-router';

// Define a tela de detalhes.
export default function Detalhes() {
  return (
    <View style={styles.container}>
      {/* Imagem do destino. */}
      <Image
        source={require('../assets/praia.png')}
        style={styles.imagem}
      />

      {/* Nome do destino. */}
      <Text style={styles.titulo}>Rio de Janeiro</Text>

      {/* Descrição da viagem. */}
      <Text style={styles.texto}>
        Conheça praias, montanhas e diversos pontos turísticos
        em uma das cidades mais conhecidas do Brasil.
      </Text>

      {/* Preço de exemplo. */}
      <Text style={styles.preco}>A partir de R$ 1.500,00</Text>

      {/* Volta para a tela de destinos. */}
      <Link href="/destinos" asChild>
        <TouchableOpacity style={styles.botao}>
          <Text style={styles.textoBotao}>Voltar para destinos</Text>
        </TouchableOpacity>
      </Link>
    </View>
  );
}

// Define os estilos.
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  imagem: {
    width: '100%',
    height: 220,
    borderRadius: 10,
    marginBottom: 20,
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  texto: {
    fontSize: 17,
    textAlign: 'center',
    lineHeight: 25,
    marginBottom: 15,
  },
  preco: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  botao: {
    backgroundColor: '#1976D2',
    padding: 13,
    borderRadius: 8,
    width: 220,
  },
  textoBotao: {
    color: 'white',
    textAlign: 'center',
    fontSize: 16,
  },
});