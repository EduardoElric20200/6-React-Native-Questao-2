// Importa o Stack para criar a navegação entre telas.
import { Stack } from 'expo-router';

// Define o layout principal.
export default function Layout() {
  return (
    <Stack>
      {/* Tela inicial. */}
      <Stack.Screen name="index" options={{ title: 'Início' }} />
      {/* Tela de destinos. */}
      <Stack.Screen name="destinos" options={{ title: 'Destinos' }} />
      {/* Tela de detalhes. */}
      <Stack.Screen name="detalhes" options={{ title: 'Detalhes' }} />
    </Stack>
  );
}