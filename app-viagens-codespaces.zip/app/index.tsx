// Importa componentes do React Native.
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

// Importa o Link para navegar entre telas.
import { Link } from 'expo-router';

// Define a tela inicial.
export default function Inicio() {
  return (
    <View style={styles.container}>
      {/* Logo do aplicativo. */}
      <Image source={require('../assets/logo.png')} style={styles.logo} />

      {/* Nome do aplicativo. */}
      <Text style={styles.titulo}>Viaja+</Text>

      {/* Texto de apresentação. */}
      <Text style={styles.texto}>
        Encontre destinos incríveis para sua próxima viagem.
      </Text>

      {/* Link para a tela de destinos. */}
      <Link href="/destinos" asChild>
        <TouchableOpacity style={styles.botao}>
          <Text style={styles.textoBotao}>Ver destinos</Text>
        </TouchableOpacity>
      </Link>
    </View>
  );
}

// Define os estilos.
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    width: 130,
    height: 130,
    marginBottom: 15,
  },
  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  texto: {
    fontSize: 17,
    textAlign: 'center',
    marginBottom: 25,
  },
  botao: {
    backgroundColor: '#1976D2',
    padding: 14,
    borderRadius: 8,
    width: 200,
  },
  textoBotao: {
    color: 'white',
    textAlign: 'center',
    fontSize: 17,
  },
});